import React from 'react'
import './Title.css'

const Title = ({ title, subtitle1, subtitle2}) => {
  return (
    <div className='title'>
        <h1>{title}</h1>
        <p>{subtitle1}</p>
        <p>{subtitle2}</p>
    </div>
  )
}

export default Title