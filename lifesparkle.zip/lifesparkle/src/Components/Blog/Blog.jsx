import React from 'react';
import './Blog.css';
import msg_icon from '../../assets/msg-icon.jpg';
import crown from '../../assets/crown.png';
import heart from '../../assets/heart-icon.png';
import eye from '../../assets/eye-icon.jpg';
import { Link } from 'react-router-dom';

const Blog = ({ blog_img, profile, title, subtitle, author_name, d_t, seen, comments, likes, Links }) => {
  return (
    <div className='blog'>
      <img src={blog_img} alt="Blog" className='blog-img' />
      <div className='description'>
        <div className='desc'>
          <div className="author">
            <img src={profile} alt="Author" className='profile-img' />
            <div>
              <span className="name">
                {author_name}
                <img src={crown} alt="Crown" />
              </span>
              <span className="d-t">{d_t}</span>
            </div>
          </div>
          <h2>
            <Link to={Links}>{title}</Link>
          </h2>
          <p>
            <Link to={Links}>{subtitle}</Link>
          </p>
        </div>
        <div className="icons">
          <div className="icon2">
            <span>
              <img src={eye} alt="Views" /> {seen}
            </span>
            <span>
              <img src={msg_icon} alt="Comments" /> {comments}
            </span>
          </div>
          <div className="icon1">
            <span>
              {likes} <img src={heart} alt="Likes" />
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Blog;
