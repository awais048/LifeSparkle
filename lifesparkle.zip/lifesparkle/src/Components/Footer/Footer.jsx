import React from 'react'
import './Footer.css'
import f_logo from '../../assets/f-logo.jpg'
import i_logo from '../../assets/i-logo.avif'
import t_logo from '../../assets/t-logo.png'


const Footer = () => {
  return (
    <div className='footer '>
        <div className="left">
            <h2>About us</h2>
            <p className='p'>At Lifesparkle, we believe in the transformative power of simplicity and joy. Our platform is more than a lifestyle blog; it's a sanctuary for those seeking a balance between everyday living and moments of sheer delight.</p>
            <p >© All rights reserved.</p>
        </div>
        <div className="right">
            <h2>Join My Mailing List</h2>
            <form>
                <label htmlFor="">Email *</label>
                <input type="email" />
                <button>Subscribe Now</button>
            </form>
            <div className='social-media'> 
                <img src={f_logo} alt="" />
                <img src={i_logo} alt="" />
                <img src={t_logo} alt="" />
            </div>
        </div>
    </div>
  )
}

export default Footer