import React from 'react';
import './Blogg.css';
import crown from '../../assets/crown.png';
import { Link } from 'react-router-dom';

const Blogg = ({ blog_img, profile, title, subtitle, author_name, d_t, Links }) => {
  return (
    <div className='blogg'>
        <img src={blog_img} alt="Blog" className='blog-img' />
        <div className='description'>
            <div className='desc'>
                <div className="author">
                    <img src={profile} alt="Author" className='profile-img' />
                    <div>
                        <span className="name">{author_name}<img src={crown} alt="Crown" /></span>
                        <span className="d-t">
                            {d_t}
                        </span>
                    </div>
                </div>
                <h2><Link to={Links}>{title}</Link></h2>
                <p><Link to={Links}>{subtitle}</Link></p>
            </div>
        </div>
    </div>
  );
}

export default Blogg;
