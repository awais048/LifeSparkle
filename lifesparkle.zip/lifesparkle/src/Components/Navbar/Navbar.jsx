import React, { useState } from 'react';
import './Navbar.css';
import { NavLink, Outlet } from 'react-router-dom';
import logo from '../../assets/logo.jpg';
import s_icon from '../../assets/s-icon.png';
import f_logo from '../../assets/f-logo.jpg';
import i_logo from '../../assets/i-logo.avif';
import t_logo from '../../assets/t-logo.png';
import menu_icon from '../../assets/menu-icon.png';

const Navbar = () => {
  const [mobileMenu, setMobileMenu] = useState(false);

  const toggleMenu = () => {
    setMobileMenu(prev => !prev);
  };

  const closeMenu = () => {
    setMobileMenu(false);
  };

  return (
    <>
      <nav>
        <img src={logo} alt="Logo" />
        <div className="search">
          <input type="text" placeholder="Search..." />
          <img src={s_icon} alt="Search Icon" />
        </div>
        <div className={`links ${mobileMenu ? 'mobile-menu' : ''}`}>
          <li>
            <NavLink to="/Home" className={({ isActive }) => (isActive ? 'active-link' : '')} onClick={closeMenu}>
              Home
            </NavLink>
          </li>
          <li>
            <NavLink to="/Lifestyle" className={({ isActive }) => (isActive ? 'active-link' : '')} onClick={closeMenu}>
              Lifestyle
            </NavLink>
          </li>
          <li>
            <NavLink to="/Fashion" className={({ isActive }) => (isActive ? 'active-link' : '')} onClick={closeMenu}>
              Fashion
            </NavLink>
          </li>
          <li>
            <NavLink to="/Travel" className={({ isActive }) => (isActive ? 'active-link' : '')} onClick={closeMenu}>
              Travel
            </NavLink>
          </li>
          <li>
            <NavLink to="/Technology" className={({ isActive }) => (isActive ? 'active-link' : '')} onClick={closeMenu}>
              Technology
            </NavLink>
          </li>
          <li>
            <NavLink to="/Home_deco" className={({ isActive }) => (isActive ? 'active-link' : '')} onClick={closeMenu}>
              Home Decor
            </NavLink>
          </li>
        </div>
        <img src={menu_icon} alt="Menu Icon" onClick={toggleMenu} className="menu-icon" />
        <div className="social-media">
          <img src={f_logo} alt="Facebook Logo" />
          <img src={i_logo} alt="Instagram Logo" />
          <img src={t_logo} alt="Twitter Logo" />
        </div>
      </nav>
      <Outlet />
    </>
  );
};

export default Navbar;
