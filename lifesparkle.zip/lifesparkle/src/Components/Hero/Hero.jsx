import React from 'react'
import './Hero.css'

const Hero = () => {
  return (
    <div className='hero'>
        <h1>Life Sparkle</h1>
        <p>Welcome to Life Sparkle, your ultimate destination for inspiration and guidance on living a vibrant, fulfilling life. Our mission is to empower you with the tools and insights you need to enhance every aspect of your existence, from personal growth and wellness to style and adventure...</p>
        <button>Read more</button>
    </div>
  )
}

export default Hero