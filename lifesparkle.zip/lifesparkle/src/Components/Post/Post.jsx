import React from 'react'
import './Post.css'
import crown from '../../assets/crown.png';
const Post = ({profile, author_name, d_t}) => {
  return (
    <div className='post'>
        <div className="author">
            <img src={profile} alt="Author" className='profile-img' />
              <div>
                  <span className="name">{author_name}<img src={crown} alt="Crown" /></span>
                  <span className="d-t">
                      {d_t}
                  </span>
              </div>
        </div>
    </div>
  )
}

export default Post