import './Categories.css';
import { useState } from 'react';
import back_icon from '../../assets/back-icon.png'
import next_icon from '../../assets/next-icon.png'

const Categories = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const categories = [
    { name: 'Travel', className: 'c1', link: './Travel' },
    { name: 'Technology', className: 'c2', link: './Technology' },
    { name: 'Fashion', className: 'c3', link: './Fashion' },
    { name: 'Home Deco', className: 'c4', link: './Home_deco' },
    { name: 'Lifestyle', className: 'c5', link: './Lifestyle' } 
  ];

  const nextSlide = () => {
    setCurrentSlide((prevSlide) => (prevSlide + 1) % categories.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prevSlide) => (prevSlide - 1 + categories.length) % categories.length);
  };

  return (
    <div className='categories'>
      <div className="wc">
        <p>Welcome to LeisureApes, your haven for simplicity and joy. Explore the art of leisure with our diverse content, featuring travel adventures, fashion trends, the latest in tech, and inspiring home decor ideas. Join us on this vibrant journey where every post is crafted to add a touch of joy and inspiration to your daily life</p>
      </div>
      <div className="slider-container">
        <div className="slider" style={{ transform: `translateX(-${currentSlide * 100}%)` }}>
          {categories.map((category, index) => (
            <div className={`category ${category.className}`} key={index}>
              <h2><a href={category.link}>{category.name}</a></h2>
            </div>
          ))}
        </div>
        <button className="nav-button next" onClick={nextSlide}><img src={next_icon} alt="" /></button>
        <button className="nav-button prev" onClick={prevSlide}><img src={back_icon} alt="" /></button>
      </div>
    </div>
  );
};

export default Categories;
