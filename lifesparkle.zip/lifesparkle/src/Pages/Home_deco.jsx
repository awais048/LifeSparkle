import React from 'react'
import Title from '../Components/Title/Title'
import Blog from '../Components/Blog/Blog'
import Footer from '../Components/Footer/Footer'
import blog1_img from '../assets/Home deco/blog1-img.jpg'
import blog2_img from '../assets/Home deco/blog2-img.jpg'
import blog1_profile from '../assets/Home deco/blog1-profile.jpg'
import blog2_profile from '../assets/Home deco/blog2-profile.jpg'
import './style.css'

const Home_deco = () => {
  return (
    <div className='home-deco'>
      <div className="container1">
      <Title 
        title='Home Deco' 
        subtitle1="Step into Lifespakle's Home Decor Haven — where design meets emotion, and every article is a brushstroke," 
        subtitle2="turning your space into a canvas of comfort and style"
      />
      <div className="blogs">
        <Blog  
          blog_img={blog1_img} 
          profile={blog1_profile} 
          title="Merging Vintage Charm with Modern Elegance in Your Living Spaces"
          subtitle="Home decor is more than just aesthetic; it's about creating a sanctuary. Discover how to blend vintage charm with modern elegance for a unique living space..."
          author_name="Peter Flipp"
          d_t="Oct 15,2023 . 4 min"
          seen='900'
          comments='91'
          likes='97'
          Links='/H_Blog1'
        />
         <Blog  
          blog_img={blog2_img} 
          profile={blog2_profile} 
          title="Crafting Inspirational Spaces: A Guide to Functional and Stylish Home Offices"
          subtitle="Your workspace should inspire creativity and productivity. Today, we’ll explore how to design a home office that is both functional and stylish..."
          author_name="Daniel Trust Ndamwizeye"
          d_t="Nov 15,2021 . 1 min"
          seen='770'
          comments='10'
          likes='52'
          Links='/H_Blog2'
        />
      </div>
      </div>
      <Footer/>
    </div>
  )
}

export default Home_deco