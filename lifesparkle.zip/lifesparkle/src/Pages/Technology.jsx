import React from 'react'
import Title from '../Components/Title/Title'
import Blog from '../Components/Blog/Blog'
import Footer from '../Components/Footer/Footer'
import blog1_img from '../assets/Technology/blog1-img.jpg'
import blog2_img from '../assets/Technology/blog2-img.jpg'
import blog1_profile from '../assets/Technology/blog1-profile.jpg'
import blog2_profile from '../assets/Technology/blog2-profile.jpg'
import './style.css'

const Technology = () => {
  return (
    <div className='technology'>
      <div className="container1">
      <Title 
        title='Technology' 
        subtitle1="Enter Lifespakle's Tech Hub — where innovation meets insight, unraveling the latest in technology." 
        subtitle2="Explore a realm of articles guiding you through the ever-evolving landscape, from cutting-edge gadgets to future tech trends."
      />
      <div className="blogs">
        <Blog  
          blog_img={blog1_img} 
          profile={blog1_profile} 
          title="The Future of Smart Homes: Integrating Technology for a Seamless Living Experience"
          subtitle="Smart technology is revolutionizing the way we live. Let’s explore the latest advancements in smart home integration and how they can enhance your living experience..."
          author_name="Greg Clark"
          d_t="Dec 18,2024 . 2 min"
          seen='40'
          comments='10'
          likes='20'
          Links='/Te_Blog1'
        />
         <Blog  
          blog_img={blog2_img} 
          profile={blog2_profile} 
          title="Wearable Tech Trends: How Innovations Are Shaping Our Daily Lives"
          subtitle="Wearable technology is not just a fad; it’s a game-changer. Today, we’ll delve into the latest trends in wearable tech and their impact on our daily routines..."
          author_name="Mohcine Aoki"
          d_t="April 18,2024 . 2 min"
          seen='77'
          comments='3'
          likes='55'
          Links='/Te_Blog2'
        />
      </div>
      </div>
      <Footer/>
    </div>
  )
}

export default Technology