import React from 'react'
import Title from '../Components/Title/Title'
import Blog from '../Components/Blog/Blog'
import Footer from '../Components/Footer/Footer'
import blog1_img from '../assets/travel/blog1-img.jpg'
import blog2_img from '../assets/travel/blog2-img.jpg'
import blog1_profile from '../assets/travel/blog1-profile.jpeg'
import blog2_profile from '../assets/travel/blog2-profile.jpg'
import './style.css'

const Travel = () => {
  return (
    <div className='travel'>
      <div className="container1">
      <Title 
        title='Travel' 
        subtitle1="We Embark on a journey with Lifesparkle' Wanderlust Chronicles — where every destination becomes a chapter in your travel story." 
        subtitle2="Explore our curated articles, unlocking the wonders of the world, from hidden gems to iconic landmarks, inspiring your next adventure."
      />
      <div className="blogs">
        <Blog  
          blog_img={blog1_img} 
          profile={blog1_profile} 
          title="From Urban Jungles to Secluded Beaches: A Comprehensive Travel Guide for the Modern Explorer"
          subtitle="Traveling opens the door to new experiences and cultures. Let’s embark on a journey through bustling cities and tranquil beaches, discovering hidden gems along the way..."
          author_name="Adam Gallagher"
          d_t="Aug 1,2022 . 3 min"
          seen='70'
          comments='7'
          likes='18'
          Links='/Tr_Blog1'
        />
        <Blog  
          blog_img={blog2_img} 
          profile={blog2_profile} 
          title="Navigating the World's Most Fashion-Forward Cities: A Stylist's Travel Diary"
          subtitle="Fashion isn't confined to runways; it's alive in the streets of the world’s cities. Join me as we navigate through the most fashion-forward destinations..."
          author_name="Tommy Lei"
          d_t="Feb 11,2024 . 9 min"
          seen='400'
          comments='18'
          likes='57'
          Links='/Tr_Blog2'
        />
      </div>
      </div>
      <Footer/>
    </div>
  )
}

export default Travel