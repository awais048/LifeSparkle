import React from 'react'
import Post from '../../../Components/Post/Post'
import Blog2_profile from '../../../assets/Home deco/blog2-profile.jpg' 
import Blog2_img from '../../../assets/Home deco/blog2-img.jpg' 
import '../../Posts/blogs.css'
import Blogg from '../../../Components/Blogg/Blogg'
import Blog1_profile from '../../../assets/travel/blog1-profile.jpeg';
import Blog1_img from '../../../assets/travel/blog1-img.jpg';
import Blog3_profile from '../../../assets/Technology/blog2-profile.jpg';
import Blog3_img from '../../../assets/Technology/blog2-img.jpg';


import Footer from '../../../Components/Footer/Footer'


const Blog2 = () => {
  return (
    <div className='post'>
      <div className="container1 m-top">
        <Post profile={Blog2_profile} author_name='Daniel Trust Ndamwizeye' d_t='Nov 15,2021 . 1 min'/>
        <div className="blog-writing">
          <h1>Crafting Inspirational Spaces: A Guide to Functional and Stylish Home Offices</h1>
          <p> In today's fast-paced world, the home office has become an essential sanctuary for productivity, creativity, and inspiration. In this guide, we'll explore how to design functional and stylish home offices that cater to your unique needs and preferences, allowing you to work and thrive in a space that inspires creativity and fosters focus.</p>
          <img src={Blog2_img} alt="" />
          <p>Before diving into the design process, take some time to consider how you'll be using your home office and what your specific needs are. Are you primarily working from home, pursuing creative endeavors, or managing household tasks and finances? Understanding your purpose and priorities will help guide the design and layout of your home office to ensure it meets your practical and functional requirements.
            <br /><br />
            Creating a workspace that prioritizes comfort and ergonomics is essential for long-term health and productivity. Invest in a quality ergonomic chair that provides proper support for your back and promotes good posture, and position your desk at the appropriate height to minimize strain on your wrists and neck. Consider incorporating adjustable standing desks or ergonomic accessories like keyboard trays and monitor stands to customize your setup to suit your individual needs. <br /><br />

            A clutter-free workspace is essential for maintaining focus and productivity. Incorporate ample storage solutions to keep your home office tidy and organized, such as shelving units, filing cabinets, and storage bins. Opt for multifunctional furniture pieces with built-in storage</p>
        </div>
        <div className="span">More posts</div>
      </div>
      <div className="other-blogs">
        <div className="other-one">
          <Blogg  
            blog_img={Blog1_img} 
            profile={Blog1_profile} 
            title="From Urban Jungles to Secluded Beaches: A Comprehensive Travel Guide for the Modern Explorer"
            subtitle="Traveling opens the door to new experiences and cultures. Let’s embark on a journey through bustling cities and tranquil beaches, discovering hidden gems along the way..."
            author_name="Adam Gallagher"
            d_t="Aug 1,2022 . 3 min"
            Links='/Tr_Blog1'
          />
        </div>
        <div className="other-one">
          <Blogg  
            blog_img={Blog3_img} 
            profile={Blog3_profile} 
            title="Mastering Minimalism: Achieving Timeless Style with Simple, Muted Tones"
            subtitle="In a world obsessed with trends, the beauty of minimalism often gets overshadowed. Today, let's focus on creating timeless looks with earthy and muted tones..."
            author_name="Carl Thompson"
            d_t="Feb 18, 2022 . 2 min"
            Links='/Te_Blog2'
          />
          </div>
      </div>
        <Footer/>
        
    </div>
  )
}

export default Blog2