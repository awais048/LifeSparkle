import React from 'react'
import Post from '../../../Components/Post/Post'
import Blog3_profile from '../../../assets/fashion/blog3-profile.jpg' 
import Blog3_img from '../../../assets/fashion/blog3-img.jpg' 
import '../../Posts/blogs.css'
import Blogg from '../../../Components/Blogg/Blogg';
import Blog1_profile from '../../../assets/Technology/blog1-profile.jpg';
import Blog1_img from '../../../assets/Technology/blog1-img.jpg';
import Blog2_profile from '../../../assets/fashion/blog2-profile.jpg';
import Blog2_img from '../../../assets/fashion/blog2-img.jpg';


import Footer from '../../../Components/Footer/Footer'


const Blog3 = () => {
  return (
    <div className='post'>
      <div className="container1 m-top">
        <Post profile={Blog3_profile} author_name='Bryan Boy' d_t='Nov 18,2023 . 6 min'/>
        <div className="blog-writing">
          <h1>From Runway to Reality: How to Incorporate High-Fashion Trends into Everyday Wear</h1>
          <p> In the fast-paced landscape of technology, innovations are not just confined to our smartphones and laptops; they are increasingly finding their way into our wardrobes as well. Wearable technology has emerged as a dynamic intersection of fashion and functionality, revolutionizing the way we interact with the world around us. Today, we delve into the latest wearable tech trends and explore how these innovations are shaping our daily lives.</p>
          <img src={Blog3_img} alt="" />
          <p>Smartwatches have evolved far beyond their initial function of simply telling time. Today's smartwatches are equipped with a myriad of features, including fitness tracking, heart rate monitoring, GPS navigation, and even contactless payment capabilities. With sleek designs and customizable interfaces, smartwatches seamlessly integrate into our daily routines, helping us stay connected and informed while on the go. <br /> <br />
          Fitness trackers have become indispensable tools for individuals looking to take control of their health and wellness. These wearable devices monitor various metrics such as steps taken, calories burned, sleep patterns, and heart rate, providing valuable insights into our physical activity and overall well-being. With advanced sensors and intuitive apps, fitness trackers empower us to set and achieve fitness goals, leading to healthier lifestyles and improved quality of life. <br /> <br />
          The convergence of fashion and technology has given rise to smart clothing, garments embedded with sensors and electronics to enhance functionality and performance. From temperature-regulating fabrics to biometric monitoring systems, smart clothing offers a glimpse into the future of fashion, where style meets innovation. Whether it's a smart jacket that adjusts its insulation based on weather conditions or a fitness shirt that tracks your workout intensity, these futuristic garments are redefining the boundaries of wearable tech. <br /> <br />
            <br />From smartwatches to AR glasses, wearable technology is transforming the way we live, work, and play. With continuous innovation and advancements in design and functionality, wearable tech trends are shaping our daily lives in unprecedented ways, offering new avenues for connectivity, convenience, and personalization. As we embrace these innovations, we embark on an exciting journey towards a future where technology seamlessly integrates into every aspect of our lives, enhancing our experiences and enriching our human potential.</p>
        </div>
        <div className="span">More posts</div>
      </div>
      <div className="other-blogs">
        <div className="other-one">
          <Blogg  
            blog_img={Blog2_img} 
            profile={Blog2_profile} 
            title="Mastering Minimalism: Achieving Timeless Style with Simple, Muted Tones"
            subtitle="In a world obsessed with trends, the beauty of minimalism often gets overshadowed. Today, let's focus on creating timeless looks with earthy and muted tones..."
            author_name="Carl Thompson"
            d_t="Feb 18,2022 . 2 min"
            Links='/F_Blog2'
          />
          </div>
          <div className="other-one">
          <Blogg  
            blog_img={Blog1_img} 
            profile={Blog1_profile} 
            title="The Future of Smart Homes: Integrating Technology for a Seamless Living Experience"
            subtitle="Smart technology is revolutionizing the way we live. Let’s explore the latest advancements in smart home integration and how they can enhance your living experience..."
            author_name="Greg Clark"
            d_t="Dec 18,2024 . 2 min"
            Links='/Te_Blog1'
          />
        </div>
      </div>
        <Footer/>
        
    </div>
  )
}

export default Blog3