import React from 'react'
import Title from '../Components/Title/Title'
import Blog from '../Components/Blog/Blog'
import Footer from '../Components/Footer/Footer'
import blog1_img from '../assets/lifestyle/blog1-img.jpg'
import blog1_profile from '../assets/lifestyle/blog1-profile.jpg'
import './style.css'

const Lifestyle = () => {
  return (
    <div className='lifestyle'>
      <div className="container1">
      <Title 
        title='Lifestyle' 
        subtitle1="Welcome to Lifespakle's Lifestyle Chronicles, where every post unfolds a tapestry of inspiration and practical insights." 
        subtitle2="Join us in navigating the art of living well, embracing style, wellness, and the joy of everyday moments."
      />
      <div className="blogs">
        <Blog  
          blog_img={blog1_img} 
          profile={blog1_profile} 
          title="Balancing Career and Wellness: Tips for a Holistic Lifestyle Approach"
          subtitle="Achieving balance between career ambitions and personal wellness is crucial. Let’s explore practical tips for maintaining a holistic lifestyle approach..."
          author_name="Nebula Johnson"
          d_t="Mar 18,2024 . 2 min"
          seen='4'
          comments='1'
          likes='2'
          Links='/L_Blog1'
        />
      </div>
      </div>
      <Footer/>
    </div>
  )
}

export default Lifestyle