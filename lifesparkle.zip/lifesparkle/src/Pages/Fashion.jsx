import React from 'react'
import Title from '../Components/Title/Title'
import Footer from '../Components/Footer/Footer'
import './style.css'
import blog1_img from '../assets/fashion/blog1-img.jpg'
import blog1_profile from '../assets/fashion/blog1-profile.jpg'
import blog2_img from '../assets/fashion/blog2-img.jpg'
import blog2_profile from '../assets/fashion/blog2-profile.jpg'
import blog3_img from '../assets/fashion/blog3-img.jpg'
import blog3_profile from '../assets/fashion/blog3-profile.jpg'
import Blog from '../Components/Blog/Blog'


const Fashion = () => {
  return (
      <div className="fashion">
       <div className=" container1">
       <Title 
          title='Fashion' 
          subtitle1="Welcome to Lifespakle's Style Oasis — where fashion meets expression." 
          subtitle2="Discover a curated collection of articles unraveling the latest trends, style tips, and the art of crafting your unique sartorial story"
        />
         <div className="blogs">
          <Blog  
            blog_img={blog1_img} 
            profile={blog1_profile} 
            title="Exploring Bold Patterns and Masculine Silhouettes to Elevate Your Street Style Game"
            subtitle="Fashion is not just about clothing; it's an expression of individuality. Today, we dive into the art of mixing traditionally feminine silhouettes with masculine elements..."
            author_name="Justin Livingston"
            d_t="May 1,2023 . 2 min"
            seen='400'
            comments='8'
            likes='34'
            Links='/F_Blog1'
          />
           <Blog  
            blog_img={blog2_img} 
            profile={blog2_profile} 
            title="Mastering Minimalism: Achieving Timeless Style with Simple, Muted Tones"
            subtitle="In a world obsessed with trends, the beauty of minimalism often gets overshadowed. Today, let's focus on creating timeless looks with earthy and muted tones..."
            author_name="Carl Thompson"
            d_t="Feb 18,2022 . 2 min"
            seen='700'
            comments='40'
            likes='180'
            Links='/F_Blog2'
          />
           <Blog  
            blog_img={blog3_img} 
            profile={blog3_profile} 
            title="Wearable Tech Trends: How Innovations Are Shaping Our Daily Lives"
            subtitle="Wearable technology is not just a fad; it’s a game-changer. Today, we’ll delve into the latest trends in wearable tech and their impact on our daily routines..."
            author_name="Mohcine Aoki"
            d_t="April 18,2024 . 2 min"
            seen='70'
            comments='8'
            likes='7'
            Links='/F_Blog3'
          />
        </div>
       </div>
       <Footer/>
      </div>
    )
  }

  export default Fashion
