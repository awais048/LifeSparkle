import React from 'react'
// import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from './Components/Navbar/Navbar'
import Home from './Pages/Home'
import Fashion from './Pages/Fashion'
import Lifestyle from './Pages/Lifestyle'
import Technology from './Pages/Technology'
import Travel from './Pages/Travel'
import Home_deco from './Pages/Home_deco';
import F_Blog1 from './Pages/Posts/fashion_post/Blog1';
import F_Blog2 from './Pages/Posts/fashion_post/Blog2';
import F_Blog3 from './Pages/Posts/fashion_post/Blog3';
import H_Blog1 from './Pages/Posts/home deco post/Blog1';
import H_Blog2 from './Pages/Posts/home deco post/Blog2';
import L_Blog1 from './Pages/Posts/life style post/Blog1';
import Te_Blog1 from './Pages/Posts/technology post/Blog1';
import Te_Blog2 from './Pages/Posts/technology post/Blog2';
import Tr_Blog1 from './Pages/Posts/travel post/Blog1';
import Tr_Blog2 from './Pages/Posts/travel post/Blog2';



const App = () => {
  return (
    <div>

      <BrowserRouter>
      <Navbar/>
      <Routes>
          <Route index element={<Home/>} />
          <Route path="home" element={<Home />} />
          <Route path="lifestyle" element={<Lifestyle />} />
          <Route path="fashion" element={<Fashion />} />
          <Route path="travel" element={<Travel />} />
          <Route path="technology" element={<Technology />} />
          <Route path="home_deco" element={<Home_deco />} />
          <Route path="F_blog1" element={<F_Blog1/>} />
          <Route path="F_blog2" element={<F_Blog2/>} />
          <Route path="F_blog3" element={<F_Blog3/>} />
          <Route path="H_blog1" element={<H_Blog1/>} />
          <Route path="H_blog2" element={<H_Blog2/>} />
          <Route path="Te_blog1" element={<Te_Blog1/>} />
          <Route path="Te_blog2" element={<Te_Blog2/>} />
          <Route path="Tr_blog1" element={<Tr_Blog1/>} />
          <Route path="Tr_blog2" element={<Tr_Blog2/>} />
          <Route path="L_blog1" element={<L_Blog1/>} />
        
      </Routes>
    </BrowserRouter>
    </div>
   
  )
}

export default App